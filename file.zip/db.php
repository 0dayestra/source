<?php
$servername = base64_decode("MXhoLmguZmlsZXNzLmlv");
$username = base64_decode("Q09MREFUQV9jb21iaW5lZWFy");
$password = base64_decode("OGFmNmRjY2RiOWZjZmNhZGM3ZTRlYzQ4OTg2MzhkZGRlYWJhMjdhNg");
$dbname = base64_decode("Q09MREFUQV9jb21iaW5lZWFy");
// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 2: Find the 'logs' table
$tableName = "logs";

// Step 3: Retrieve all columns from the 'logs' table
$sql = "SELECT * FROM $tableName";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Step 4: Check if 'country' or 'isp' columns are null or empty
        $country = $row['country'];
        $isp = $row['isp'];
        $ip = $row['ipaddres'];
		$mobile = $row['host'];

        if (empty($mobile)) {
            // Step 5: Get info about the IP using ip-api.com
            $url = "http://ip-api.com/php/{$ip}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query";

            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($curl);
            curl_close($curl);
            
            $info = unserialize($response);
            
			$status = isset($info['status']) ? $info['status'] : '';
            $status = preg_replace('/[^a-zA-Z0-9\s]/', '', $status); // Remove special characters
            $status = $conn->real_escape_string($status); // Escape quotes
			
            $country = isset($info['country']) ? $info['country'] : '';
            $country = preg_replace('/[^a-zA-Z0-9\s]/', '', $country); // Remove special characters
            $country = $conn->real_escape_string($country); // Escape quotes
            

            $city = isset($info['city']) ? $info['city'] : '';
            $city = preg_replace('/[^a-zA-Z0-9\s]/', '', $city); // Remove special characters
            $city = $conn->real_escape_string($city); // Escape quotes
			
			
			$regionName = isset($info['regionName']) ? $info['regionName'] : '';
            $regionName = preg_replace('/[^a-zA-Z0-9\s]/', '', $regionName); // Remove special characters
            $regionName = $conn->real_escape_string($regionName); // Escape quotes
			
			if ($regionName == "Île-de-France") { 
			
			$regionName = "le-de-France";
			}
			$isp = isset($info['isp']) ? $info['isp'] : '';
            $isp = preg_replace('/[^a-zA-Z0-9\s]/', '', $isp); // Remove special characters
            $isp = $conn->real_escape_string($isp); // Escape quotes
            if ($status == "fail") {
			 $country =	"Unknown";
			 $city ="Unknown";
			 $regionName ="Unknown";
			 $isp ="Private Range";
			
			}
			$mobile = isset($info['mobile']) ? $conn->real_escape_string($info['mobile']) : '';
			if ($mobile == 1) {
			$mobile = "True";
			}else{
			$mobile = "False";	
			}
			$proxy = isset($info['proxy']) ? $conn->real_escape_string($info['proxy']) : '';
			if ($proxy == 1) {
			$proxy = "True";
			}else{
			$proxy = "False";	
			}
			$hosting = isset($info['hosting']) ? $conn->real_escape_string($info['hosting']) : '';
			if ($hosting == 1) {
			$hosting = "True";
			}else{
			$hosting = "False";	
			}
            $host = gethostbyaddr($ip);
            $updateSql = "UPDATE $tableName SET country = '$country', isp = '$isp', host = '$host', mobile = '$mobile', proxy = '$proxy', hosting = '$hosting', city = '$city', region = '$regionName' WHERE id = {$row['id']}";

            if ($conn->query($updateSql) === true) {
                // Prepare the data to be sent back to the client
                $output = "Row with ID {$row['id']} updated successfully.\n";
            } else {
                $output = "Error updating row with ID {$row['id']}: " . $conn->error . "\n";
            }

            // Send the output to the client
            echo '<script>console.log("' . addslashes($output) . '");</script>';
            echo '<p>' . $output . '</p>';

            // Flush the output buffer to ensure immediate delivery
            flush();
            ob_flush();
        }
    }
} else {
    $output = "No rows found in the 'logs' table.\n";
    echo '<script>console.log("' . addslashes($output) . '");</script>';
    echo '<p>' . $output . '</p>';
}

// Close the database connection
$conn->close();
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Function to update the result dynamically
        function updateResult(output) {
            // Append the output to a result container element
            $('#result-container').append('<p>' + output + '</p>');
        }

        // Function to start the update process
        function startUpdate() {
            $.ajax({
                url: '',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    // Check if there is an output in the response
                    if (response.output) {
                        // Update the result dynamically
                        updateResult(response.output);
                    }

                    // Start the update process recursively
                    startUpdate();
                },
                error: function() {
                    // Handle errors, if any
                }
            });
        }

        // Start the initial update process
        startUpdate();
    });
</script>

<div id="result-container"></div>

